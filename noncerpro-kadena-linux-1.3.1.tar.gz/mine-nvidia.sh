#!/bin/bash

./noncerpro --address=abf6f1c3d583dfc180189a4ad6c5bfa62b29fa2669dad25b8c6d700dbd3c96f8  --platform nvidia --server=bigchungusmining.energy --port=4200 

