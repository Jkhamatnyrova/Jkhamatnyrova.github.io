#!/bin/bash

./noncerpro  --platform amd

